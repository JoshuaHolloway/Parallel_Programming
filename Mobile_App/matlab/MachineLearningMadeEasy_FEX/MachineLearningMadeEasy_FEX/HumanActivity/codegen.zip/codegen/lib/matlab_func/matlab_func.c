/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: matlab_func.c
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 05-Apr-2018 07:10:16
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "matlab_func.h"

/* Function Definitions */

/*
 * Arguments    : double x
 *                double y
 * Return Type  : double
 */
double matlab_func(double x, double y)
{
  return x + y;
}

/*
 * File trailer for matlab_func.c
 *
 * [EOF]
 */
