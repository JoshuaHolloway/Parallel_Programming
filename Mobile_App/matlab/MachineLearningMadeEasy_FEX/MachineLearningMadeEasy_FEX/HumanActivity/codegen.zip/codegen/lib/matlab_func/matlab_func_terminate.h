/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: matlab_func_terminate.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 05-Apr-2018 07:10:16
 */

#ifndef MATLAB_FUNC_TERMINATE_H
#define MATLAB_FUNC_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "matlab_func_types.h"

/* Function Declarations */
extern void matlab_func_terminate(void);

#endif

/*
 * File trailer for matlab_func_terminate.h
 *
 * [EOF]
 */
