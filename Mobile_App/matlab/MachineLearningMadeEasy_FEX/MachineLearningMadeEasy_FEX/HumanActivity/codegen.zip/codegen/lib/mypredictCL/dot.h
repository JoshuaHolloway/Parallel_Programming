/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: dot.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 04-Apr-2018 06:26:45
 */

#ifndef DOT_H
#define DOT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "mypredictCL_types.h"

/* Function Declarations */
extern void b_dot(const double a[1000], const double b[1000], double c[500]);
extern void c_dot(const double a[706], const double b[706], double c[353]);
extern void d_dot(const double a[1210], const double b[1210], double c[605]);
extern void dot(const double a[634], const double b[634], double c[317]);
extern void e_dot(const double a[1710], const double b[1710], double c[855]);

#endif

/*
 * File trailer for dot.h
 *
 * [EOF]
 */
