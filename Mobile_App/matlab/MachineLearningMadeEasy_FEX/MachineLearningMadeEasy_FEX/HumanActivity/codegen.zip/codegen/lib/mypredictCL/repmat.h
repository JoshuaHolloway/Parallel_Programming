/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: repmat.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 04-Apr-2018 06:26:45
 */

#ifndef REPMAT_H
#define REPMAT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "mypredictCL_types.h"

/* Function Declarations */
extern void repmat(const double a[15], double b[30]);

#endif

/*
 * File trailer for repmat.h
 *
 * [EOF]
 */
