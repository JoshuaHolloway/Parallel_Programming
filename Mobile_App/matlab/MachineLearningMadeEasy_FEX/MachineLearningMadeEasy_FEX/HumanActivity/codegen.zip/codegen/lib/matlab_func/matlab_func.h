/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: matlab_func.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 05-Apr-2018 07:10:16
 */

#ifndef MATLAB_FUNC_H
#define MATLAB_FUNC_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "matlab_func_types.h"

/* Function Declarations */
extern double matlab_func(double x, double y);

#endif

/*
 * File trailer for matlab_func.h
 *
 * [EOF]
 */
