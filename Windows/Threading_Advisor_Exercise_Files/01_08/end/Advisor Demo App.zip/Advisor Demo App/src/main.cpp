#define NOMINMAX
#define WIN32_LEAN_AND_MEAN

#include "BubbleSort.h"
#include "HeapSort.h"
#include "InsertionSort.h"
#include "MergeSort.h"
#include "QuickSort.h"
#include "SelectionSort.h"
#include "ShellSort.h"
#include "TreeSort.h"

// include Thread object for parallel task execution
#include "TaskHandler.h"

// Annotate
// Step 2.3 to do annotations
#include "advisor-annotate.h"

using namespace std;

int main()
{
	// normally you would want to generate a seed in order to have truly random numbers
	// but lets have rand return the usuals. 
	// load 1024 random values into array
	for (int i = 0; i < ARRAY_SIZE; i++)
	{
		g_pUnsorted[i] = rand();
	}

	ANNOTATE_TASK_BEGIN(PARALLEL);

	TaskHandler bubblesorter(BubbleSort, 10, 1);
	TaskHandler insertionsorter(InsertionSort, 10, 1);
	TaskHandler selectionsorter(SelectionSort, 10, 1);
	TaskHandler quicksorter(QuickSort, 10, 1);
	TaskHandler treesorter(TreeSort, 10, 1);
	TaskHandler mergesorter(MergeSort, 10, 1);
	TaskHandler heapsorter(HeapSort, 10, 1);
	TaskHandler shellsorter(ShellSort, 10, 1);

	bubblesorter.Start();
	insertionsorter.Start();
	selectionsorter.Start();
	quicksorter.Start();
	treesorter.Start();
	mergesorter.Start();
	heapsorter.Start();
	shellsorter.Start();

	// pause this thread and let thread run in parallel 
	//Sleep(2000);

	bubblesorter.Stop();
	insertionsorter.Stop();
	selectionsorter.Stop();
	quicksorter.Stop();
	treesorter.Stop();
	mergesorter.Stop();
	heapsorter.Stop();
	shellsorter.Stop();

	ANNOTATE_TASK_END(PARALLEL);

	return 0;

}