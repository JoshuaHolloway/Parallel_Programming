#define NOMINMAX
#define WIN32_LEAN_AND_MEAN

#include "BubbleSort.h"
#include "HeapSort.h"
#include "InsertionSort.h"
#include "MergeSort.h"
#include "QuickSort.h"
#include "SelectionSort.h"
#include "ShellSort.h"
#include "TreeSort.h"

// include Thread object for parallel task execution
//#include "TaskHandler.h"

// Annotate
// Step 2.3 to do annotations
#include "advisor-annotate.h"

using namespace std;

int main()
{
	// normally you would want to generate a seed in order to have truly random numbers
	// but lets have rand return the usuals. 
	// load 1024 random values into array
	for (int i = 0; i < ARRAY_SIZE; i++)
	{
		g_pUnsorted[i] = rand();
	}

	ANNOTATE_SITE_BEGIN(SERIAL_SORTING);
	// serial execution of all 8 sorting tasks
	cout << "\n-------------------------------------------------\n";
	cout << "                BUBBLE SORT                        \n";
	cout << "---------------------------------------------------\n";
	ANNOTATE_TASK_BEGIN(BUBBLESORT);
	BubbleSort();
	ANNOTATE_TASK_END(BUBBLESORT);
	

	cout << "\n-------------------------------------------------- \n";
	cout << "              INSERTION SORT                         \n";
	cout << "---------------------------------------------------- \n";
	ANNOTATE_TASK_BEGIN(INSERTIONSORT);
	InsertionSort();
	ANNOTATE_TASK_END(INSERTIONSORT);

	cout << "\n-------------------------------------------------- \n";
	cout << "              SELECTION SORT                         \n";
	cout << "---------------------------------------------------- \n";
	ANNOTATE_TASK_BEGIN(SELECTIONSORT);
	SelectionSort();
	ANNOTATE_TASK_END(SELECTIONSORT);

	cout << "\n-------------------------------------------------- \n";
	cout << "                QUICK SORT                           \n";
	cout << "---------------------------------------------------- \n";
	ANNOTATE_TASK_BEGIN(QUICKSORT);
	QuickSort();
	ANNOTATE_TASK_END(QUICKSORT);

	cout << "\n---------------------------------------------------- \n";
	cout << "                 TREE SORT								\n";
	cout << "------------------------------------------------------ \n";
	ANNOTATE_TASK_BEGIN(TREESORT);
	TreeSort();
	ANNOTATE_TASK_END(TREESORT);

	cout << "\n-------------------------------------------------- \n";
	cout << "                MERGE SORT                           \n";
	cout << "---------------------------------------------------- \n";
	ANNOTATE_TASK_BEGIN(MERGESORT);
	MergeSort();
	ANNOTATE_TASK_END(MERGESORT);

	cout << "\n-------------------------------------------------\n";
	cout << "                 HEAP SORT                         \n";
	cout << "---------------------------------------------------\n";
	ANNOTATE_TASK_BEGIN(HEAPSORT);
	HeapSort();
	ANNOTATE_TASK_END(HEAPSORT);

	cout << "\n-------------------------------------------------- \n";
	cout << "                SHELL SORT                           \n";
	cout << "---------------------------------------------------- \n";
	ANNOTATE_TASK_BEGIN(SHELLSORT);
	ShellSort();
	ANNOTATE_TASK_END(SHELLSORT);

	ANNOTATE_SITE_END(SERIAL_SORTING);

	return 0;

}